-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         8.0.30 - MySQL Community Server - GPL
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para prestamospasivos
CREATE DATABASE IF NOT EXISTS `prestamospasivos` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `prestamospasivos`;

-- Volcando estructura para tabla prestamospasivos.bancos
CREATE TABLE IF NOT EXISTS `bancos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombre_banco` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla prestamospasivos.bancos: ~1 rows (aproximadamente)
REPLACE INTO `bancos` (`id`, `nombre_banco`, `created_at`, `updated_at`) VALUES
	(1, 'BCIE', '2024-10-18 13:17:47', '2024-10-18 13:17:47');

-- Volcando estructura para tabla prestamospasivos.cuentas
CREATE TABLE IF NOT EXISTS `cuentas` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `codigo_banco` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `numero_cuenta` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre_cuenta` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `moneda_cuenta` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla prestamospasivos.cuentas: ~3 rows (aproximadamente)
REPLACE INTO `cuentas` (`id`, `codigo_banco`, `numero_cuenta`, `nombre_cuenta`, `moneda_cuenta`, `created_at`, `updated_at`) VALUES
	(1, 'BCR', '123-BCR', 'BANCO COSTA RICA', 'USD', NULL, NULL),
	(2, 'BNCR', '456-BNCR', 'BANCO NACIONAL', 'USD', NULL, NULL),
	(3, 'BCT', '789-BCT', 'BANCO BCT', 'USD', NULL, NULL);

-- Volcando estructura para tabla prestamospasivos.detalle_recibos
CREATE TABLE IF NOT EXISTS `detalle_recibos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `recibo_id` bigint unsigned NOT NULL,
  `numero_cuota` int unsigned NOT NULL,
  `monto_principal` decimal(8,2) NOT NULL,
  `monto_intereses` decimal(8,2) NOT NULL,
  `monto_seguro` decimal(8,2) NOT NULL,
  `monto_otros` decimal(8,2) NOT NULL,
  `monto_cuota` decimal(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `detalle_recibos_recibo_id_foreign` (`recibo_id`),
  CONSTRAINT `detalle_recibos_recibo_id_foreign` FOREIGN KEY (`recibo_id`) REFERENCES `recibos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla prestamospasivos.detalle_recibos: ~0 rows (aproximadamente)

-- Volcando estructura para tabla prestamospasivos.empresas
CREATE TABLE IF NOT EXISTS `empresas` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombre_empresa` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla prestamospasivos.empresas: ~2 rows (aproximadamente)
REPLACE INTO `empresas` (`id`, `nombre_empresa`, `created_at`, `updated_at`) VALUES
	(2, 'ATI', '2024-10-18 05:48:19', '2024-10-18 05:48:19'),
	(3, 'ORBE', '2024-10-29 21:57:45', '2024-11-05 04:40:00');

-- Volcando estructura para tabla prestamospasivos.lineas
CREATE TABLE IF NOT EXISTS `lineas` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombre_linea` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla prestamospasivos.lineas: ~1 rows (aproximadamente)
REPLACE INTO `lineas` (`id`, `nombre_linea`, `created_at`, `updated_at`) VALUES
	(1, 'LINEA BCIE 100K', '2024-10-18 13:18:10', '2024-10-18 13:18:10');

-- Volcando estructura para tabla prestamospasivos.planpagos
CREATE TABLE IF NOT EXISTS `planpagos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `prestamo_id` bigint unsigned NOT NULL,
  `numero_cuota` int unsigned NOT NULL,
  `fecha_pago` date NOT NULL,
  `monto_principal` decimal(8,2) NOT NULL,
  `monto_interes` decimal(8,2) NOT NULL,
  `monto_seguro` decimal(8,2) NOT NULL,
  `monto_otros` decimal(8,2) NOT NULL,
  `saldo_prestamo` decimal(8,2) unsigned zerofill NOT NULL DEFAULT '000000.00',
  `tasa_interes` decimal(8,2) unsigned zerofill NOT NULL DEFAULT '000000.00',
  `saldo_principal` decimal(8,2) unsigned NOT NULL DEFAULT '0.00',
  `saldo_interes` decimal(8,2) unsigned zerofill NOT NULL DEFAULT '000000.00',
  `saldo_seguro` decimal(8,2) unsigned zerofill NOT NULL DEFAULT '000000.00',
  `saldo_otros` decimal(8,2) unsigned zerofill NOT NULL DEFAULT '000000.00',
  `observaciones` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `planpagos_prestamo_id_foreign` (`prestamo_id`),
  CONSTRAINT `planpagos_prestamo_id_foreign` FOREIGN KEY (`prestamo_id`) REFERENCES `prestamos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla prestamospasivos.planpagos: ~15 rows (aproximadamente)
REPLACE INTO `planpagos` (`id`, `prestamo_id`, `numero_cuota`, `fecha_pago`, `monto_principal`, `monto_interes`, `monto_seguro`, `monto_otros`, `saldo_prestamo`, `tasa_interes`, `saldo_principal`, `saldo_interes`, `saldo_seguro`, `saldo_otros`, `observaciones`, `created_at`, `updated_at`) VALUES
	(1, 8, 1, '2024-12-04', 400.00, 50.00, 0.00, 0.00, 000000.00, 000000.00, 0.00, 000000.00, 000000.00, 000000.00, NULL, '2024-11-05 02:01:57', '2024-11-05 02:01:57'),
	(2, 9, 1, '2024-12-04', 500.00, 50.00, 0.00, 0.00, 000000.00, 000000.00, 0.00, 000000.00, 000000.00, 000000.00, NULL, '2024-11-05 02:09:39', '2024-11-05 02:09:39'),
	(3, 10, 1, '2024-12-04', 300.00, 50.00, 0.00, 0.00, 000000.00, 000000.00, 0.00, 000000.00, 000000.00, 000000.00, NULL, '2024-11-05 04:14:27', '2024-11-05 04:14:27'),
	(4, 10, 2, '2025-01-04', 300.00, 50.00, 0.00, 0.00, 000000.00, 000000.00, 0.00, 000000.00, 000000.00, 000000.00, NULL, '2024-11-05 04:14:27', '2024-11-05 04:14:27'),
	(5, 11, 1, '2024-12-04', 300.00, 50.00, 0.00, 0.00, 000000.00, 000000.00, 0.00, 000000.00, 000000.00, 000000.00, NULL, '2024-11-05 04:17:33', '2024-11-05 04:17:33'),
	(6, 11, 2, '2025-01-04', 300.00, 50.00, 0.00, 0.00, 000000.00, 000000.00, 0.00, 000000.00, 000000.00, 000000.00, NULL, '2024-11-05 04:17:33', '2024-11-05 04:17:33'),
	(7, 11, 3, '2025-02-04', 100.00, 25.00, 0.00, 0.00, 000000.00, 000000.00, 0.00, 000000.00, 000000.00, 000000.00, NULL, '2024-11-05 04:17:33', '2024-11-05 04:17:33'),
	(8, 12, 1, '2024-12-04', 800.00, 50.00, 0.00, 0.00, 000000.00, 000000.00, 0.00, 000000.00, 000000.00, 000000.00, NULL, '2024-11-05 04:23:58', '2024-11-05 04:23:58'),
	(9, 13, 1, '2024-12-04', 900.00, 100.00, 0.00, 0.00, 000000.00, 000000.00, 0.00, 000000.00, 000000.00, 000000.00, NULL, '2024-11-05 04:27:06', '2024-11-05 04:27:06'),
	(10, 14, 1, '2024-12-04', 1000.00, 50.00, 0.00, 0.00, 000000.00, 000000.00, 0.00, 000000.00, 000000.00, 000000.00, NULL, '2024-11-05 04:33:30', '2024-11-05 04:33:30'),
	(11, 15, 1, '2024-12-04', 101.00, 50.00, 0.00, 1.00, 000000.00, 000000.00, 0.00, 000000.00, 000000.00, 000000.00, NULL, '2024-11-05 04:36:11', '2024-11-05 04:36:11'),
	(12, 16, 1, '2024-12-04', 102.00, 5.00, 5.00, 5.00, 000000.00, 000000.00, 0.00, 000000.00, 000000.00, 000000.00, NULL, '2024-11-05 04:46:41', '2024-11-05 04:46:41'),
	(13, 17, 1, '2024-12-04', 10.00, 2.00, 1.00, 1.00, 000000.00, 000000.00, 0.00, 000000.00, 000000.00, 000000.00, NULL, '2024-11-05 05:14:18', '2024-11-05 05:14:18'),
	(14, 18, 1, '2024-12-04', 2.00, 1.00, 1.00, 1.00, 000000.00, 000000.00, 0.00, 000000.00, 000000.00, 000000.00, NULL, '2024-11-05 05:17:37', '2024-11-05 05:17:37'),
	(15, 19, 1, '2024-12-04', 105.00, 5.00, 6.00, 6.00, 000000.00, 000000.00, 0.00, 000000.00, 000000.00, 000000.00, NULL, '2024-11-05 05:21:37', '2024-11-05 05:21:37');

-- Volcando estructura para tabla prestamospasivos.prestamos
CREATE TABLE IF NOT EXISTS `prestamos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `empresa_id` bigint unsigned NOT NULL,
  `numero_prestamo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `banco_id` bigint unsigned NOT NULL,
  `linea_id` bigint unsigned NOT NULL,
  `forma_pago` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `moneda` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `formalizacion` date NOT NULL,
  `vencimiento` date NOT NULL,
  `proximo_pago` date NOT NULL,
  `monto_prestamo` decimal(8,2) NOT NULL,
  `saldo_prestamo` decimal(8,2) NOT NULL,
  `plazo_meses` int unsigned NOT NULL,
  `tipotasa_id` bigint unsigned NOT NULL,
  `tasa_interes` decimal(8,2) NOT NULL,
  `tasa_spreed` decimal(8,2) NOT NULL,
  `cuenta_desembolso` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estado` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `periodicidad_pago` int unsigned NOT NULL,
  `observacion` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `prestamos_empresa_id_foreign` (`empresa_id`),
  KEY `prestamos_banco_id_foreign` (`banco_id`),
  KEY `prestamos_linea_id_foreign` (`linea_id`),
  KEY `prestamos_tipo_tasa_id_foreign` (`tipotasa_id`) USING BTREE,
  CONSTRAINT `prestamos_banco_id_foreign` FOREIGN KEY (`banco_id`) REFERENCES `bancos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `prestamos_empresa_id_foreign` FOREIGN KEY (`empresa_id`) REFERENCES `empresas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `prestamos_linea_id_foreign` FOREIGN KEY (`linea_id`) REFERENCES `lineas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla prestamospasivos.prestamos: ~19 rows (aproximadamente)
REPLACE INTO `prestamos` (`id`, `empresa_id`, `numero_prestamo`, `banco_id`, `linea_id`, `forma_pago`, `moneda`, `formalizacion`, `vencimiento`, `proximo_pago`, `monto_prestamo`, `saldo_prestamo`, `plazo_meses`, `tipotasa_id`, `tasa_interes`, `tasa_spreed`, `cuenta_desembolso`, `estado`, `periodicidad_pago`, `observacion`, `created_at`, `updated_at`) VALUES
	(1, 2, '123456', 1, 1, 'A', 'USD', '2024-10-18', '2024-12-04', '2024-10-18', 100000.00, 100000.00, 24, 1, 10.00, 4.50, '123211', 'A', 12, 'abc', '2024-10-18 13:30:48', '2024-11-05 01:13:36'),
	(2, 2, '123456', 1, 1, 'A', 'USD', '2024-10-18', '2024-10-18', '2024-10-18', 10.00, 10.00, 24, 1, 10.00, 10.00, '10', 'A', 12, '10', '2024-10-18 13:46:40', '2024-10-18 13:46:40'),
	(3, 2, '123456', 1, 1, 'V', 'USD', '2024-10-18', '2024-10-18', '2024-10-18', 11.00, 11.00, 11, 2, 11.00, 11.00, '1', 'A', 1, '1', '2024-10-18 13:58:49', '2024-10-18 13:58:49'),
	(4, 2, '001', 1, 1, 'V', 'USD', '2024-10-18', '2024-10-18', '2024-10-18', 20.00, 10.00, 1, 1, 1.00, 1.00, '2020', 'A', 12, 'SSS', '2024-10-19 00:35:40', '2024-10-19 00:35:40'),
	(5, 2, '100', 1, 1, 'V', 'USD', '2024-11-04', '2025-02-04', '2024-12-04', 100000.00, 100000.00, 3, 1, 5.00, 2.00, '123', 'A', 12, '123', '2024-11-05 01:17:46', '2024-11-05 01:17:46'),
	(6, 2, '200', 1, 1, 'V', 'USD', '2024-11-04', '2024-12-04', '2024-12-04', 200.00, 200.00, 1, 1, 10.00, 5.00, '123', 'A', 12, '123', '2024-11-05 01:56:14', '2024-11-05 01:56:14'),
	(7, 2, '300', 1, 1, 'V', 'USD', '2024-11-04', '2024-12-04', '2024-12-04', 300.00, 300.00, 1, 1, 10.00, 5.00, '123', 'A', 12, '123', '2024-11-05 01:59:06', '2024-11-05 01:59:06'),
	(8, 2, '400', 1, 1, 'V', 'USD', '2024-12-04', '2024-12-04', '2024-12-04', 400.00, 400.00, 1, 1, 6.00, 3.00, '123', 'A', 12, '123', '2024-11-05 02:01:57', '2024-11-05 02:01:57'),
	(9, 2, '500', 1, 1, 'V', 'USD', '2024-11-04', '2024-12-04', '2024-12-04', 500.00, 500.00, 1, 1, 5.00, 3.00, '123', 'A', 12, '123', '2024-11-05 02:09:39', '2024-11-05 02:09:39'),
	(10, 2, '600', 1, 1, 'V', 'USD', '2024-11-04', '2025-01-04', '2024-12-04', 600.00, 600.00, 2, 1, 6.00, 3.00, '123', 'A', 12, '123', '2024-11-05 04:14:27', '2024-11-05 04:14:27'),
	(11, 2, '700', 1, 1, 'V', 'USD', '2024-11-04', '2025-02-04', '2024-12-04', 700.00, 700.00, 3, 1, 5.00, 3.00, '1213', 'A', 12, '122', '2024-11-05 04:17:33', '2024-11-05 04:17:33'),
	(12, 2, '800', 1, 1, 'V', 'USD', '2024-11-04', '2024-12-04', '2024-12-04', 800.00, 800.00, 1, 1, 5.00, 3.00, '123', 'A', 12, '123', '2024-11-05 04:23:58', '2024-11-05 04:23:58'),
	(13, 2, '900', 1, 1, 'V', 'USD', '2024-12-04', '2024-12-04', '2024-12-04', 900.00, 900.00, 1, 1, 5.00, 3.00, '123', 'A', 12, '123', '2024-11-05 04:27:06', '2024-11-05 04:27:06'),
	(14, 2, '1000', 1, 1, 'V', 'USD', '2024-11-04', '2024-12-04', '2024-12-04', 1000.00, 1000.00, 1, 1, 5.00, 3.00, '213', 'A', 12, '213', '2024-11-05 04:33:30', '2024-11-05 04:33:30'),
	(15, 2, '101', 1, 1, 'V', 'USD', '2024-11-04', '2024-12-04', '2024-12-04', 101.00, 101.00, 1, 1, 5.00, 3.00, '123', 'A', 12, '123', '2024-11-05 04:36:11', '2024-11-05 04:36:11'),
	(16, 2, '102', 1, 1, 'V', 'USD', '2024-11-04', '2024-12-04', '2024-12-04', 102.00, 101.00, 1, 1, 5.00, 2.00, '123', 'A', 12, '123', '2024-11-05 04:46:41', '2024-11-05 04:46:41'),
	(17, 2, '103', 1, 1, 'V', 'USD', '2024-11-04', '2026-11-04', '2024-12-04', 103.00, 103.00, 24, 1, 8.00, 3.00, '123', 'A', 12, '123', '2024-11-05 05:14:18', '2024-11-05 05:14:18'),
	(18, 2, '104', 1, 1, 'V', 'USD', '2024-11-04', '2025-11-04', '2024-12-04', 104.00, 104.00, 12, 1, 8.00, 4.00, '1', 'A', 12, '1', '2024-11-05 05:17:37', '2024-11-05 05:17:37'),
	(19, 2, '105', 1, 1, 'V', 'USD', '2024-11-04', '2024-12-04', '2024-12-04', 105.00, 105.00, 1, 1, 10.00, 10.00, '5', 'A', 12, '5', '2024-11-05 05:21:37', '2024-11-05 05:21:37');

-- Volcando estructura para tabla prestamospasivos.productos
CREATE TABLE IF NOT EXISTS `productos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombre_producto` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla prestamospasivos.productos: ~1 rows (aproximadamente)
REPLACE INTO `productos` (`id`, `nombre_producto`, `created_at`, `updated_at`) VALUES
	(1, 'LINEA AAA+', '2024-11-02 03:18:37', '2024-11-02 03:18:37');

-- Volcando estructura para tabla prestamospasivos.recibos
CREATE TABLE IF NOT EXISTS `recibos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `empresa_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prestamo_id` bigint unsigned NOT NULL,
  `tipo_recibo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `detalle` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `estado` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'I',
  `cuenta_id` bigint unsigned NOT NULL,
  `monto_recibo` decimal(8,2) NOT NULL,
  `fecha_pago` date NOT NULL,
  `fecha_deposito` date NOT NULL,
  `razon_anulacion` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha_anulacion` date DEFAULT NULL,
  `saldo_anterior` decimal(8,2) DEFAULT '0.00',
  `saldo_actual` decimal(8,2) DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recibos_prestamo_id_foreign` (`prestamo_id`),
  KEY `recibos_cuenta_id_foreign` (`cuenta_id`),
  CONSTRAINT `recibos_cuenta_id_foreign` FOREIGN KEY (`cuenta_id`) REFERENCES `cuentas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `recibos_prestamo_id_foreign` FOREIGN KEY (`prestamo_id`) REFERENCES `prestamos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla prestamospasivos.recibos: ~1 rows (aproximadamente)
REPLACE INTO `recibos` (`id`, `empresa_id`, `prestamo_id`, `tipo_recibo`, `detalle`, `estado`, `cuenta_id`, `monto_recibo`, `fecha_pago`, `fecha_deposito`, `razon_anulacion`, `fecha_anulacion`, `saldo_anterior`, `saldo_actual`, `created_at`, `updated_at`) VALUES
	(1, '2', 5, 'CN', 'asf', 'I', 2, 801.00, '2024-11-04', '2024-11-04', NULL, NULL, 0.00, 0.00, '2024-11-05 09:50:28', '2024-11-05 09:50:28');

-- Volcando estructura para tabla prestamospasivos.tipotasas
CREATE TABLE IF NOT EXISTS `tipotasas` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombre_tipo_tasa` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla prestamospasivos.tipotasas: ~2 rows (aproximadamente)
REPLACE INTO `tipotasas` (`id`, `nombre_tipo_tasa`, `created_at`, `updated_at`) VALUES
	(1, 'PRIME', '2024-10-18 12:33:13', '2024-10-18 12:33:13'),
	(2, 'LIBOR', '2024-10-18 12:33:21', '2024-10-18 12:33:21');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
